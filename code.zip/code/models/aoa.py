from layers.dynamic_rnn import DynamicLSTM
import math
import torch
import torch.nn as nn
import torch.nn.functional as F

class AOA(nn.Module):
    def __init__(self, embedding_matrix, opt):
        super(AOA, self).__init__()
        self.opt = opt
        self.embed = nn.Embedding.from_pretrained(torch.tensor(embedding_matrix, dtype=torch.float))
        self.pos_embed = nn.Embedding(opt.max_seq_len, opt.position_dim)
        self.ctx_lstm = DynamicLSTM(opt.embed_dim, opt.hidden_dim, num_layers=1, batch_first=True, bidirectional=True,rnn_type='LSTM')
        self.asp_lstm = DynamicLSTM(opt.embed_dim, opt.hidden_dim, num_layers=1, batch_first=True, bidirectional=True,rnn_type='LSTM')
        self.w = nn.Parameter(torch.Tensor(2*opt.hidden_dim, 2*opt.hidden_dim))
        self.dense = nn.Linear(2 * opt.hidden_dim, opt.polarities_dim)

    
    def locationed_memory(self, memory, memory_len, left_len, aspect_len):
        u = torch.zeros(memory.size(0), memory.size(1), 1).to(self.opt.device)
        for i in range(memory.size(0)):
            for idx in range(memory_len[i]):
                aspect_start = left_len[i]
                if idx < aspect_start:
                    l = aspect_start - idx                   # l = absolute distance to the aspect
                    u[i][idx][0] = idx - aspect_start
                elif idx < aspect_start + aspect_len[i]:
                    l = 0
                else: 
                    l = idx - aspect_start - aspect_len[i] + 1
                    u[i][idx][0] = idx - aspect_start - aspect_len[i] + 1
                memory[i][idx] *= (1-float(l)/int(memory_len[i]))
        #memory = torch.cat([memory, u], dim=2)       
        return memory

    def forward(self, inputs):
        text_raw_indices = inputs[0] # batch_size x seq_len
        aspect_indices = inputs[1] # batch_size x seq_len
        text_left_indices=inputs[2]
        batch_size = text_raw_indices.size(0)
        ctx_len = torch.sum(text_raw_indices != 0, dim=1)
        asp_len = torch.sum(aspect_indices != 0, dim=1)
        left_len=torch.sum(text_left_indices!=0,dim=1)
        ctx = self.embed(text_raw_indices) # batch_size x seq_len x embed_dim
        asp = self.embed(aspect_indices) # batch_size x seq_len x embed_dim
        ctx_out, (_, _) = self.ctx_lstm(ctx, ctx_len) #  batch_size x (ctx) seq_len x 2*hidden_dim
        #ctx_out=self.locationed_memory(ctx_out,ctx_len)  #128*n*2d+1
        #ctx_out=self.locationed_memory(ctx_out,ctx_len,left_len,asp_len)#128*n*600
        asp_out, (_, _) = self.asp_lstm(asp, asp_len) # batch_size x (asp) seq_len x 2*hidden_dim
        interaction_mat = torch.matmul(ctx_out,torch.transpose(asp_out,1,2))
        #interaction_mat = torch.matmul(ctx_out, self.w.expand(batch_size, -1, -1)).matmul(torch.transpose(asp_out,1,2)) # batch_size x (ctx) seq_len x (asp) seq_len
        alpha = F.softmax(interaction_mat, dim=1) # col-wise, batch_size x (ctx) seq_len x (asp) seq_len
        beta = F.softmax(interaction_mat, dim=2) # row-wise, batch_size x (ctx) seq_len x (asp) seq_len
        '''
        beta_avg = beta.mean(dim=1, keepdim=True) # batch_size x 1 x (asp) seq_len
        gamma = torch.matmul(alpha, beta_avg.transpose(1, 2)) # batch_size x (ctx) seq_len x 1
        weighted_sum = torch.matmul(torch.transpose(ctx_out, 1, 2), gamma).squeeze(-1) # batch_size x 2*hidden_dim
        out = self.dense(weighted_sum) # batch_size x polarity_dim
        '''
        
        #  average
        alpha_avg=alpha.mean(dim=2,keepdim=True)   #128*N*1
        #print(alpha_avg.size())
        weighted_sum=torch.matmul(torch.transpose(ctx_out,1,2),alpha_avg).squeeze(-1)
        out = self.dense(weighted_sum) # batch_size x polarity_dim
        
        '''
        #  sum
        alpha_sum=torch.sum(alpha,dim=2)  #128*N
        alpha_sum=alpha_sum.unsqueeze(-1)  #128*N*1
        print(alpha_sum.size())
        weighted_sum=torch.matmul(torch.transpose(ctx_out,1,2),alpha_sum).squeeze(-1)
        out = self.dense(weighted_sum) # batch_size x polarity_dim
        '''
        
        '''
        #our
        alpha=torch.mul(alpha,beta)
        gamma=torch.sum(alpha,dim=2)
        gamma = torch.unsqueeze(gamma, 2)
        weighted_sum = torch.matmul(torch.transpose(ctx_out, 1, 2), gamma).squeeze(-1) 
        out = self.dense(weighted_sum)  # batch_size x polarity_dim
        '''

        '''
        #max
        alpha_max=torch.max(alpha,2,keepdim=False)[0]
        alpha_max=alpha_max.unsqueeze(-1)
        print(alpha_max.size())
        weighted_sum=torch.matmul(torch.transpose(ctx_out,1,2),alpha_max).squeeze(-1)
        out = self.dense(weighted_sum) # batch_size x polarity_dim
        '''
        return out