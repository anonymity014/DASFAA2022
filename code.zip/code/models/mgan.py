from layers.dynamic_rnn import DynamicLSTM
import torch
import torch.nn as nn
import torch.nn.functional as F


class MGAN(nn.Module):
    def __init__(self, embedding_matrix, opt):
        super(MGAN, self).__init__()
        self.opt = opt
        self.embed = nn.Embedding.from_pretrained(torch.tensor(embedding_matrix, dtype=torch.float))
        self.pos_embed = nn.Embedding(opt.max_seq_len, opt.position_dim)
        self.ind_embed = nn.Embedding(opt.max_seq_len, opt.indicator_dim)
        self.ctx_lstm = DynamicLSTM(opt.embed_dim+opt.position_dim+opt.indicator_dim, opt.hidden_dim, num_layers=1, batch_first=True, bidirectional=True,rnn_type='LSTM')
        self.asp_lstm = DynamicLSTM(opt.embed_dim, opt.hidden_dim, num_layers=1, batch_first=True, bidirectional=True,rnn_type='LSTM')
        self.w_a2c = nn.Parameter(torch.Tensor(2*opt.hidden_dim, 2*opt.hidden_dim))
        self.w_c2a = nn.Parameter(torch.Tensor(2*opt.hidden_dim, 2*opt.hidden_dim))
        self.w_max = nn.Parameter(torch.Tensor(2 * opt.hidden_dim, 2 * opt.hidden_dim))
        self.m_max = nn.Parameter(torch.Tensor(2 * opt.hidden_dim, 2 * opt.hidden_dim))
        self.U_c = nn.Parameter(torch.Tensor(2 * opt.hidden_dim, 1))
        self.U_t= nn.Parameter(torch.Tensor(2 * opt.hidden_dim, 1))
        self.dense = nn.Linear(4*opt.hidden_dim, 4*opt.hidden_dim)
        self.dropout = nn.Dropout(0.5)
        self.activation = nn.Tanh()
        self.activation1 = nn.ELU()
        self.classifier = nn.Linear(4*opt.hidden_dim, opt.polarities_dim)

    def forward(self, inputs):
        text_raw_indices = inputs[0] # batch_size x seq_len
        aspect_indices = inputs[1]
        text_left_indices= inputs[2]
        position_tag = inputs[3]
        indicator_tag = inputs[4]
        batch_size = text_raw_indices.size(0)
        ctx_len = torch.sum(text_raw_indices != 0, dim=1)
        asp_len = torch.sum(aspect_indices != 0, dim=1)
        left_len = torch.sum(text_left_indices != 0, dim=-1)
        aspect_in_text = torch.cat([left_len.unsqueeze(-1), (left_len+asp_len-1).unsqueeze(-1)], dim=-1)

        ctx = self.embed(text_raw_indices) # batch_size x seq_len x embed_dim
        position = self.pos_embed(position_tag)
        indicator=self.ind_embed(indicator_tag)
        ctx = torch.cat((position, ctx,indicator), dim=-1)  # batch_size x seq_len x (embed_dim+50)

        asp = self.embed(aspect_indices) # batch_size x seq_len x embed_dim

        ctx_out, (_, _) = self.ctx_lstm(ctx, ctx_len)
        asp_out, (_, _) = self.asp_lstm(asp, asp_len)  # batch_size x (asp)seq_len x 2*hidden_dim

        con_max_pool=torch.max(ctx_out,1,keepdim=False)[0]
        con_max_pool=con_max_pool.unsqueeze(-1)

        ctx_pool = torch.sum(ctx_out, dim=1)
        ctx_pool = torch.div(ctx_pool, ctx_len.float().unsqueeze(-1)).unsqueeze(-1) # batch_size x 2*hidden_dim x 1

        asp_max_pool = torch.max(asp_out, 1, keepdim=False)[0]
        asp_max_pool = asp_max_pool.unsqueeze(-1)

        asp_pool = torch.sum(asp_out, dim=1)
        asp_pool = torch.div(asp_pool, asp_len.float().unsqueeze(-1)).unsqueeze(-1) # batch_size x 2*hidden_dim x 1

        c_asp2ctx_max = F.softmax(ctx_out.matmul(self.w_max.expand(batch_size, -1, -1)).matmul(asp_max_pool), dim=1)
        max_c_asp2ctx = torch.matmul(ctx_out.transpose(1, 2), c_asp2ctx_max).squeeze(-1)

        c_ctx2asp_max = F.softmax(asp_out.matmul(self.m_max.expand(batch_size, -1, -1)).matmul(con_max_pool), dim=1)
        max_c_ctx2asp = torch.matmul(asp_out.transpose(1, 2), c_ctx2asp_max).squeeze(-1)

        c_asp2ctx_alpha = F.softmax(ctx_out.matmul(self.w_a2c.expand(batch_size, -1, -1)).matmul(asp_pool), dim=1)
        c_asp2ctx = torch.matmul(ctx_out.transpose(1, 2), c_asp2ctx_alpha).squeeze(-1)
        #128*m*2d  128*2d*2d  128*n*1
        c_ctx2asp_alpha = F.softmax(asp_out.matmul(self.w_c2a.expand(batch_size, -1, -1)).matmul(ctx_pool), dim=1)
        c_ctx2asp = torch.matmul(asp_out.transpose(1, 2), c_ctx2asp_alpha).squeeze(-1)

        cuda = torch.device('cuda')
        e=torch.ones(batch_size,1,300,device=cuda)
        interaction_mat = torch.matmul(ctx_out,
        torch.transpose(asp_out, 1, 2))  # batch_size x (ctx) seq_len x (asp) seq_len
        alpha = F.softmax(interaction_mat, dim=1)  # col-wise, batch_size x (ctx) seq_len x (asp) seq_len
        beta = F.softmax(interaction_mat, dim=2)  # row-wise, batch_size x (ctx) seq_len x (asp) seq_le
        M=alpha.mul(beta)
        #print(M.size())
        alpha_avg = M.mean(dim=2, keepdim=True)  # 128*N*1
        beta_avg=beta.mean(dim=1,keepdim=True) #128*1*(m+2k)

        '''
        Wc=torch.add(ctx_out, torch.matmul(alpha_avg,e).mul(ctx_out))
        Wc=torch.matmul(Wc, self.U_c.expand(batch_size, -1, -1))
        Wc=self.activation1(Wc)  #  batch*n*1

        Wt=torch.add(asp_out,torch.matmul(torch.transpose(beta_avg, 1, 2),e).mul(asp_out))
        Wt = torch.matmul(Wt, self.U_t.expand(batch_size, -1, -1))
        Wt = self.activation1(Wt)  # batch*(m+2k)*1
        weighted_sum1 = torch.matmul(torch.transpose(asp_out, 1, 2), Wt).squeeze(-1)
        weighted_sum2 = torch.matmul(torch.transpose(ctx_out, 1, 2), Wc).squeeze(-1)
        '''
        weighted_sum = torch.matmul(torch.transpose(ctx_out, 1, 2), alpha_avg).squeeze(-1)

        feat = torch.cat([weighted_sum,c_ctx2asp], dim=1)
        output = self.dense(feat)
        output = self.activation(output)
        output = self.dropout(output)
        out=self.classifier(output) # bathc_size x polarity_dim

        return out
