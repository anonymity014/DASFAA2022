import collections
import os
import random
from shutil import copyfile
import pandas as pd
import numpy as np
from EDA import *
from multiprocessing import  Process
try:
    import xml.etree.ElementTree as ET, getopt, logging, sys, random, re, copy
    from xml.sax.saxutils import escape
except:
    sys.exit('Some package is missing... Perhaps <re>?')
import warnings
warnings.filterwarnings("ignore")
logging.basicConfig(format = '%(asctime)s - %(levelname)s - %(name)s -   %(message)s',
                    datefmt = '%m/%d/%Y %H:%M:%S',
                    level = logging.INFO)
logger = logging.getLogger(__name__)
import torch
if torch.cuda.is_available():
    device = torch.device("cuda")
    print('There are %d GPU(s) available.' % torch.cuda.device_count())
    print('We will use the GPU:', torch.cuda.get_device_name(0))
else:
    print('No GPU available, using the CPU instead.')
    device = torch.device("cpu")
import random
random.seed(1720)
# stop words list
stop_words = ['i', 'me', 'my', 'myself', 'we', 'our',
              'ours', 'ourselves', 'you', 'your', 'yours',
              'yourself', 'yourselves', 'he', 'him', 'his',
              'himself', 'she', 'her', 'hers', 'herself',
              'it', 'its', 'itself', 'they', 'them', 'their',
              'theirs', 'themselves', 'what', 'which', 'who',
              'whom', 'this', 'that', 'these', 'those', 'am',
              'is', 'are', 'was', 'were', 'be', 'been', 'being',
              'have', 'has', 'had', 'having', 'do', 'does', 'did',
              'doing', 'a', 'an', 'the', 'and', 'but', 'if', 'or',
              'because', 'as', 'until', 'while', 'of', 'at',
              'by', 'for', 'with', 'about', 'against', 'between',
              'into', 'through', 'during', 'before', 'after',
              'above', 'below', 'to', 'from', 'up', 'down', 'in',
              'out', 'on', 'off', 'over', 'under', 'again',
              'further', 'then', 'once', 'here', 'there', 'when',
              'where', 'why', 'how', 'all', 'any', 'both', 'each',
              'few', 'more', 'most', 'other', 'some', 'such', 'no',
              'nor', 'not', 'only', 'own', 'same', 'so', 'than', 'too',
              'very', 's', 't', 'can', 'will', 'just', 'don',
              'should', 'now', ',','.','']

def softmax(x):
    x_exp = np.exp(x)
    x_sum = np.sum(x_exp, axis = 0, keepdims = True)
    s = x_exp / x_sum
    return s

def  ps2list(source_path):
    file = open(source_path)
    lines = file.readlines()
    ps_list = []
    for i in range(len(lines)):
        ps_list.append(float(lines[i].strip('\r\n')))
    return ps_list

def  find_ps(source_path,q,k):
    file = open(source_path)
    lines = file.readlines()
    for i in range(1,len(lines)):
        source_id, match_id, ps = lines[i].strip('\r\n').split(' ')
        if  int(source_id)==q and  int(match_id)==k:
            return float(ps)

def creat_random_list(length,n):
    random_list = random.sample(range(1, length + 1), n)
    return random_list

def create_counterfactual_samples(source_path,aspect_ps_path,matching_ps_path,aug_path):
    each_aspect_ps_path =  aspect_ps_path
    each_aspect_ps_list = ps2list(each_aspect_ps_path)
    match_aspect_ps_path =matching_ps_path
    file = open(source_path)
    lines = file.readlines()
    length = int(len(lines)/3)
   # print(length)
    Augmentation_sentence_path =  aug_path
    Augmentation_sentence_file =  open(Augmentation_sentence_path, 'a+', encoding='utf-8')
    for i in range(0, len(lines), 3):
        u = int(i / 3)
        aspect = lines[i + 1].strip('\r\n').lower()
        context = lines[i].strip('\r\n').lower()
        polarity = int(lines[i+2].strip('\r\n'))
        sentence = context.replace('$t$', aspect)
        aspect_index = context.split(' ').index('$t$')
        ps_match_dic = {}
        random_list = creat_random_list(length-1, 30)
        #print(random_list)
        for j in random_list:
            aspect_match = lines[j*3 + 1].strip('\r\n').lower()
            context_match = lines[j*3].strip('\r\n').lower()
            polarity_match = int(lines[j*3 + 2].strip('\r\n'))
            sentence_match= context_match.replace('$t$', aspect)
            aspect_index_match = context_match.split(' ').index('$t$')
            if  aspect != aspect_match and polarity == polarity_match and  sentence != sentence_match:
                ps_aspect_match = find_ps(match_aspect_ps_path,i,j*3)
                ps_match_dic[j*3] = ps_aspect_match
        if  ps_match_dic != {}:
                max_index = max(ps_match_dic, key=lambda x: ps_match_dic[x])
                if  each_aspect_ps_list[u] - ps_match_dic[max_index] < 2e-1:
                #if  1==1:
                     #print(each_aspect_ps_list[u],ps_match_dic[max_index] )
                     new_sentence = context
                     Augmentation_sentence_file.write(new_sentence + '\n'+lines[max_index+1]+ lines[i + 2])
        if  u %100 ==0:
               logger.info(' process datafile: [{}],   sentence id >>: {}'.format(source_path, u))
                     #Augmentation_sentence_file.write((lines[i] + lines[min_index+1] + lines[i + 2]))
    Augmentation_sentence_file.close()
    #print information of counterfactual samples
    Augmentation_sentence_files =  open(Augmentation_sentence_path, 'r', encoding='utf-8')
    Augmentation_sentence_lines = Augmentation_sentence_files.readlines()
    logger.info("Writing  %d  counterfactual samples to:  %s" % (len(Augmentation_sentence_lines)/3,Augmentation_sentence_path))

def  Test_selection():
    test_path = '../data/Rest14/Restaurants_Test_Gold.xml.seg'
    output_path = '../data/Rest14/Restaurants_Test_bias_Gold.xml.seg'
    test_file = open(test_path, 'r', encoding='utf-8', newline='\n', errors='ignore')
    output_file = open(output_path, 'w', encoding='utf-8')

    test_line = test_file.readlines()
    logger.info("Number of original examples = %d", len(test_line) / 3)
    aspect_term = {}
    for i in range(0, len(test_line), 3):
        aspect = test_line[i + 1].lower().strip('\r\n')
        aspect_term.setdefault(aspect,[]).append(int(i/3))
    #print(aspect_term)
    select_index = []
    for key, value in aspect_term.items():
        select_index.append(random.choice(value))
    print(select_index)
    logger.info("Number of selected testing examples = %d", len(select_index))

    for i in range(0, len(test_line), 3):
        temp=int(i/3)
        if temp in select_index:
            output_file.write((test_line[i] + test_line[i+1]+ test_line[i + 2]))
    output_file.close()
    logger.info("Test_set complete!!!")

def  multi_works(func,datafile):
    logger.info('Process start ...')
    proc_record = []
    for i in range(len(datafile)):
        p0 = Process(target=func, args=(datafile[i][0], datafile[i][1],datafile[i][2],datafile[i][3]))
        p0.start()
        proc_record.append(p0)
    for p in proc_record:
          p.join()
    logger.info('Process end ...')

def  test(source_path):
    source_file = open(source_path,'r',encoding='utf-8')
    lines = source_file.readlines()
    aspect_list = []
    for i in range(0,2703,3):
        aspect = lines[i + 1].lower().strip('\r\n')
        aspect_list.append(aspect)
    b = set(aspect_list)
    result = []
    for i in b:
        result.append([i, aspect_list.count(i)])
    result.sort(key=lambda x: (x[1], x[0]), reverse=True)
    print(result)

if __name__ == '__main__':
    dataset_files = [
       # 'Rest14':
        [
            '../data/Rest14/Restaurants_Train.xml.seg',
            '../data/Rest14/each_aspect_ps.txt',
            '../data/Rest14/match_aspect_ps.txt',
            '../data/Rest14/exchange.seg'
        ],
       #'Lap14':
        [
            '../data/Lap14/Laptops_Train.xml.seg',
            '../data/Lap14/each_aspect_ps.txt',
            '../data/Lap14/match_aspect_ps.txt',
            '../data/Lap14/exchange.seg'
        ],
        #'Rest15':
        [
            '../data/Rest15/restaurant_train.raw',
            '../data/Rest15/each_aspect_ps.txt',
            '../data/Rest15/match_aspect_ps.txt',
            '../data/Rest15/exchange.seg'
        ],
       # 'Rest16':
        [
            '../data/Res16/restaurant_train.raw',
            '../data/Res16/each_aspect_ps.txt',
            '../data/Res16/match_aspect_ps.txt',
            '../data/Res16/exchange.seg'
        ]
    ]
    multi_works(create_counterfactual_samples,dataset_files)






