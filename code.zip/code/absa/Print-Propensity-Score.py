
from multiprocessing import  Process
import numpy as np
try:
    import xml.etree.ElementTree as ET, getopt, logging, sys, random, re, copy
    from xml.sax.saxutils import escape
except:
    sys.exit('Some package is missing... Perhaps <re>?')
import warnings
warnings.filterwarnings("ignore")
logging.basicConfig(format = '%(asctime)s - %(levelname)s - %(name)s -   %(message)s',
                    datefmt = '%m/%d/%Y %H:%M:%S',
                    level = logging.INFO)
logger = logging.getLogger(__name__)
import torch
if torch.cuda.is_available():
    device = torch.device("cuda")
    print('There are %d GPU(s) available.' % torch.cuda.device_count())
    print('We will use the GPU:', torch.cuda.get_device_name(0))
else:
    print('No GPU available, using the CPU instead.')
    device = torch.device("cpu")

from transformers import BertTokenizer, BertModel, BertForMaskedLM, AutoModel, AutoTokenizer, AutoModelWithLMHead

MODEL_PATH = '../bert-large-uncased/'
VOCAB = MODEL_PATH
tokenizer = BertTokenizer.from_pretrained(VOCAB)

def softmax(x):
    x_exp = np.exp(x)
    x_sum = np.sum(x_exp, axis = 0, keepdims = True)
    s = x_exp / x_sum
    return s
def sigmoid(x):
    return 1.0/(1+np.exp(-float(x)))

def   print_each_aspect(source_path,log_path):
    files = open(source_path)
    lines = files.readlines()
    out_putfile = open(log_path, "w")
    for i in range(0,  len(lines), 3):
        logger.info("{}\n".format(i))
        logger.info(' {}, each aspect>>: {}'.format(source_path,i) )
        aspect = lines[i + 1].strip('\r\n').lower()
        context = lines[i].strip('\r\n').lower()
        sentence = context.replace('$t$', aspect)
        aspect_index = context.split(' ').index('$t$')
        ps_list = []
        for j in range(len(sentence.split(' '))):
            mask = sentence.split(' ')[j]
            text = sentence.replace(mask,"[MASK]")
            inputs = tokenizer.encode_plus(text, return_tensors="pt")
            masked_index = j
            model = BertForMaskedLM.from_pretrained(MODEL_PATH)
            model.eval()
            # Predict all tokens
            predictions = model(**inputs)[0]
            mask_id = tokenizer.convert_tokens_to_ids(mask)
            ps_list.append(predictions[0, masked_index][mask_id].detach().cpu().tolist())
        ps_aspect = softmax(ps_list)[aspect_index]
        print(ps_aspect,file=out_putfile)
    out_putfile.close()
    logger.info("=========Writing each aspect propensity score to:  %s" % (log_path))
    logger.info('=' * 100)


def   print_match_ps(source_path,log_path):
    file = open(source_path)
    lines = file.readlines()
    out_file = open(log_path, "w")
    out_file.write("{} {} {}\n".format('source_id,', 'match_id,', 'ps'))
    for i in range(0, len(lines), 3):
        logger.info(' {}, match aspect id>>: {}'.format(source_path,i) )
        aspect = lines[i + 1].strip('\r\n').lower()
        context = lines[i].strip('\r\n').lower()
        polarity = int(lines[i + 2].strip('\r\n'))
        sentence = context.replace('$t$', aspect)
        aspect_index = context.split(' ').index('$t$')
        for j in range(0,  len(lines), 3):
            aspect_match = lines[j + 1].strip('\r\n').lower()
            context_match = lines[j].strip('\r\n').lower()
            polarity_match = int(lines[j + 2].strip('\r\n'))
            sentence_match = context_match.replace('$t$', aspect)
            if aspect != aspect_match and polarity == polarity_match:
                new_sentence = sentence.replace(aspect, aspect_match)
                ps_list = []
                for k in range(len(new_sentence.split(' '))):
                    mask = new_sentence.split(' ')[k]
                    text = new_sentence.replace(mask, "[MASK]")
                    inputs = tokenizer.encode_plus(text, return_tensors="pt")
                    masked_index = k
                    model = BertForMaskedLM.from_pretrained(MODEL_PATH)
                    model.eval()
                    # Predict all tokens
                    predictions = model(**inputs)[0]
                    mask_id = tokenizer.convert_tokens_to_ids(mask)
                    ps_list.append(predictions[0, masked_index][mask_id].detach().cpu().tolist())
                ps_aspect_match = softmax(ps_list)[aspect_index]
                print("{} {} {}".format(i, j, ps_aspect_match), file=out_file)
    out_file.close()
    logger.info("====Writing each aspect propensity score to:  %s" % (log_path))
    logger.info('=' * 100)

def   calculate_aspectandmatching_ps(source_path,log_path1,log_path2):
    files = open(source_path)
    lines = files.readlines()
    aspect_file = open(log_path1, "w")
    match_file = open(log_path2, "w")
    match_file.write("{} {} {}\n".format('source_id,', 'match_id,', 'ps'))
    for i in range(0,  len(lines), 3):
        logger.info(' {}, each aspect propensity score>>: {}'.format(source_path,int(i/3)) )
        aspect = lines[i + 1].strip('\r\n').lower()
        context = lines[i].strip('\r\n').lower()
        polarity = int(lines[i + 2].strip('\r\n'))
        sentence = context.replace('$t$', aspect)
        aspect_index = context.split(' ').index('$t$')
        #for j in range(len(sentence.split(' '))):
        mask = sentence.split(' ')[aspect_index]
        text = sentence.replace(mask,"[MASK]")
        inputs = tokenizer.encode_plus(text, return_tensors="pt")
        masked_index = aspect_index
        model = BertForMaskedLM.from_pretrained(MODEL_PATH)
        model.eval()
        # Predict all tokens
        predictions = model(**inputs)[0]
        mask_id = tokenizer.convert_tokens_to_ids(mask)
        ps_aspect  = sigmoid(predictions[0, masked_index][mask_id])
        #ps_aspect = softmax(ps_list)[aspect_index]
        print(ps_aspect,file=aspect_file)
        #print(ps_aspect)

        for j in range(0, len(lines), 3):
            aspect_match = lines[j + 1].strip('\r\n').lower()
            context_match = lines[j].strip('\r\n').lower()
            polarity_match = int(lines[j + 2].strip('\r\n'))
            sentence_match = context_match.replace('$t$', aspect)
            if  aspect != aspect_match and polarity == polarity_match and sentence != sentence_match:
                mask_match_id = tokenizer.convert_tokens_to_ids(aspect_match)
                ps_match = sigmoid(predictions[0, masked_index][mask_match_id])
                print("{} {} {}".format(i, j, ps_match), file=match_file)
    aspect_file.close()
    match_file.close()
    logger.info("=========Writing each aspect propensity score to:  %s" % (log_path1))
    logger.info("=========Writing aspect matching propensity score to:  %s" % (log_path2))
    logger.info('=' * 60)

def  multi_works(func,datafile):
    logger.info('Process start ...')
    proc_record = []
    for i in range(len(datafile)):
        p0 = Process(target=func, args=(datafile[i][0], datafile[i][1],dataset_files[i][2]))
        p0.start()
        proc_record.append(p0)
    for p in proc_record:
          p.join()
    logger.info('Process end ...')

if __name__ == '__main__':

    dataset_files = [
        #'Rest14':
        [
            '../data/Rest14/Restaurants_Train.xml.seg',
            '../data/Rest14/each_aspect_ps.txt',
            '../data/Rest14/match_aspect_ps.txt'
        ],
       # 'Lap14':
        [
            '../data/Lap14/Laptops_Train.xml.seg',
            '../data/Lap14/each_aspect_ps.txt',
            '../data/Lap14/match_aspect_ps.txt'
        ],
        #'Rest15':
        [
            '../data/Rest15/restaurant_train.raw',
            '../data/Rest15/each_aspect_ps.txt',
            '../data/Rest15/match_aspect_ps.txt'
        ],
        #'Rest16':
        [
            '../data/Res16/restaurant_train.raw',
            '../data/Res16/each_aspect_ps.txt',
            '../data/Res16/match_aspect_ps.txt'
        ],
    ]


    multi_works(calculate_aspectandmatching_ps,dataset_files)





