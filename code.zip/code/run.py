import os
import subprocess
import sys
from multiprocessing import  Process
def run(command):
    subprocess.call(command, shell=True)

def sh(command):
    p = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    parameter, result, time_cost = '', '', ''
    for line in iter(p.stdout.readline, b''):
        line = line.rstrip().decode('utf8')
        if 'args:' in line:
            parameter = line
        if 'final best performance:' in line:
            result = line
        if 'Experiment cost:' in line:
            time_cost = line
    return parameter, result, time_cost

def per_data1():
    cuda_id = 0
    dataset = 'Lap14'
    model_name = 'bert_spc'
    batch_size = 32
    learning_rate = 3e-5
    num_epoch = 20
    # batch_size = 32
    # learning_rate = 1e-5
    # num_epoch = 20
    train_path = os.path.join('data/Lap14/', 'Laptops_Train.xml.seg')
    test_path = os.path.join('data/Lap14/', 'Laptops_Test_bias.xml.seg')
    for index,value in enumerate(['train-RD.seg','train-RI.seg','train-RS.seg','train-SR.seg']):
            aug_path = os.path.join('data/Lap14/', value)
            result_path = os.path.join('Result/Lap14', '%s.txt' %(10+index))  # 'Tweets,Lap14,Rest14-16',
            cmd = 'python train_k_fold.py ' + ' ' + \
                  ' --device cuda:' + str(cuda_id) + ' ' + \
                  ' --dataset ' + str(dataset) +' ' + \
                  ' --mix_ratio ' + str(1) + ' ' + \
                  ' --num_epoch ' + str(num_epoch) + ' ' + \
                  ' --batch_size ' + str(batch_size) + ' ' + \
                  ' --learning_rate ' + str(learning_rate) + ' ' + \
                  ' --model_name ' + str(model_name) + ' ' + \
                  ' --train_file ' + str(train_path) + ' ' + \
                  ' --aug_file ' + str(aug_path) + ' ' + \
                  ' --test_file ' + str(test_path) + ' ' + \
                  ' --result_file ' + str(result_path) + ' '
            run(cmd)
            sys.stdout.flush()
def per_data2():
    cuda_id = 1
    dataset = 'Res16'
    # model_name = 'aen_bert'
    # batch_size = 32
    # learning_rate = 3e-5
    # num_epoch = 20
    model_name = 'bert_spc'
    batch_size = 32
    learning_rate = 3e-5
    num_epoch = 20
    train_path = os.path.join('data/Res16/', 'restaurant_train.raw')
    test_path = os.path.join('data/Res16/', 'restaurant_test_bias.raw')
    for index, value in enumerate(['train-RD.seg', 'train-RI.seg', 'train-RS.seg', 'train-SR.seg']):
            aug_path = os.path.join('data/Res16/', value)
            result_path = os.path.join('Result/Rest16', '%s.txt' %(index+10))  # 'Tweets,Lap14,Rest14-16',
            cmd = 'python train_k_fold.py ' + ' ' + \
                  ' --device cuda:' + str(cuda_id) + ' ' + \
                  ' --dataset ' + str(dataset) +' ' + \
                  ' --mix_ratio ' + str(1) + ' ' + \
                  ' --num_epoch ' + str(num_epoch) + ' ' + \
                  ' --batch_size ' + str(batch_size) + ' ' + \
                  ' --learning_rate ' + str(learning_rate) + ' ' + \
                  ' --model_name ' + str(model_name) + ' ' + \
                  ' --train_file ' + str(train_path) + ' ' + \
                  ' --aug_file ' + str(aug_path) + ' ' + \
                  ' --test_file ' + str(test_path) + ' ' + \
                  ' --result_file ' + str(result_path) + ' '
            run(cmd)
            sys.stdout.flush()

def per_data3():
    cuda_id = 0
    dataset = 'Rest14'
    # model_name = 'aen_bert'
    # batch_size = 32
    # learning_rate = 2e-5
    # num_epoch = 20
    model_name = 'bert_spc'
    batch_size = 32
    learning_rate = 3e-5
    num_epoch = 20
    train_path = os.path.join('data/Rest14/', 'Restaurants_Train.xml.seg')
    test_path = os.path.join('data/Rest14/', 'Restaurants_Test_bias_Gold.xml.seg')
    for index, value in enumerate(['train-RD.seg', 'train-RI.seg', 'train-RS.seg', 'train-SR.seg']):
        aug_path = os.path.join('data/Rest14/', value)
        result_path = os.path.join('Result/Rest14', '%s.txt' % (index+10))  # 'Tweets,Lap14,Rest14-16',
        cmd = 'python train_k_fold.py ' + ' ' + \
              ' --device cuda:' + str(cuda_id) + ' ' + \
              ' --dataset ' + str(dataset) + ' ' + \
              ' --mix_ratio ' + str(1) + ' ' + \
              ' --num_epoch ' + str(num_epoch) + ' ' + \
              ' --batch_size ' + str(batch_size) + ' ' + \
              ' --learning_rate ' + str(learning_rate) + ' ' + \
              ' --model_name ' + str(model_name) + ' ' + \
              ' --train_file ' + str(train_path) + ' ' + \
              ' --aug_file ' + str(aug_path) + ' ' + \
              ' --test_file ' + str(test_path) + ' ' + \
              ' --result_file ' + str(result_path) + ' '
        run(cmd)
        sys.stdout.flush()

def per_data4():
    cuda_id = 1
    dataset = 'Rest15'
    # model_name = 'aen_bert'
    # batch_size = 16
    # learning_rate = 1e-5
    # num_epoch = 20
    model_name = 'bert_spc'
    batch_size = 32
    learning_rate = 3e-5
    num_epoch = 20
    train_path = os.path.join('data/Rest15/', 'restaurant_train.raw')
    test_path = os.path.join('data/Rest15/', 'restaurant_test_bias.raw')
    for index, value in enumerate(['train-RD.seg', 'train-RI.seg', 'train-RS.seg', 'train-SR.seg']):
        aug_path = os.path.join('data/Rest15/', value)
        result_path = os.path.join('Result/Rest15', '%s.txt' % (index+10))  # 'Tweets,Lap14,Rest14-16',
        cmd = 'python train_k_fold.py ' + ' ' + \
              ' --device cuda:' + str(cuda_id) + ' ' + \
              ' --dataset ' + str(dataset) + ' ' + \
              ' --mix_ratio ' + str(1) + ' ' + \
              ' --num_epoch ' + str(num_epoch) + ' ' + \
              ' --batch_size ' + str(batch_size) + ' ' + \
              ' --learning_rate ' + str(learning_rate) + ' ' + \
              ' --model_name ' + str(model_name) + ' ' + \
              ' --train_file ' + str(train_path) + ' ' + \
              ' --aug_file ' + str(aug_path) + ' ' + \
              ' --test_file ' + str(test_path) + ' ' + \
              ' --result_file ' + str(result_path) + ' '
        run(cmd)
        sys.stdout.flush()
def per_data5():
    cuda_id = 0
    dataset = 'Lap14'
    model_name = 'bert_spc'
    batch_size = 32
    learning_rate = 3e-5
    num_epoch = 20
    train_path = os.path.join('data/Lap14/', 'Laptops_Train.xml.seg')
    aug_path = os.path.join('data/Lap14/', 'Augmentation.seg')
    test_path = os.path.join('data/Lap14/', 'Laptops_Test_bias.xml.seg')
    for ratio in [1, 0, 0.9, 0.8, 0.7, 0.6, 0.5, 0.4, 0.3, 0.2, 0.1]:
            result_path = os.path.join('Result/Lap14', 'bert-spc-%s.txt' %(ratio) )  # 'Tweets,Lap14,Rest14-16',
            cmd = 'python train_k_fold.py ' + ' ' + \
                  ' --device cuda:' + str(cuda_id) + ' ' + \
                  ' --dataset ' + str(dataset) +' ' + \
                  ' --mix_ratio ' + str(ratio) + ' ' + \
                  ' --num_epoch ' + str(num_epoch) + ' ' + \
                  ' --batch_size ' + str(batch_size) + ' ' + \
                  ' --learning_rate ' + str(learning_rate) + ' ' + \
                  ' --model_name ' + str(model_name) + ' ' + \
                  ' --train_file ' + str(train_path) + ' ' + \
                  ' --aug_file ' + str(aug_path) + ' ' + \
                  ' --test_file ' + str(test_path) + ' ' + \
                  ' --result_file ' + str(result_path) + ' '
            run(cmd)
            sys.stdout.flush()
def per_data6():
    cuda_id = 1
    dataset = 'Res16'
    model_name = 'bert_spc'
    batch_size = 32
    learning_rate = 3e-5
    num_epoch = 20
    train_path = os.path.join('data/Res16/', 'restaurant_train.raw')
    aug_path = os.path.join('data/Res16/', 'Augmentation.seg')
    test_path = os.path.join('data/Res16/', 'restaurant_test_bias.raw')
    for ratio in [1, 0, 0.9, 0.8, 0.7, 0.6, 0.5, 0.4, 0.3, 0.2, 0.1]:
            result_path = os.path.join('Result/Rest16', 'bert_spc-%s.txt' %(ratio) )  # 'Tweets,Lap14,Rest14-16',
            cmd = 'python train_k_fold.py ' + ' ' + \
                  ' --device cuda:' + str(cuda_id) + ' ' + \
                  ' --dataset ' + str(dataset) +' ' + \
                  ' --mix_ratio ' + str(ratio) + ' ' + \
                  ' --num_epoch ' + str(num_epoch) + ' ' + \
                  ' --batch_size ' + str(batch_size) + ' ' + \
                  ' --learning_rate ' + str(learning_rate) + ' ' + \
                  ' --model_name ' + str(model_name) + ' ' + \
                  ' --train_file ' + str(train_path) + ' ' + \
                  ' --aug_file ' + str(aug_path) + ' ' + \
                  ' --test_file ' + str(test_path) + ' ' + \
                  ' --result_file ' + str(result_path) + ' '
            run(cmd)
            sys.stdout.flush()

def per_data7():
    cuda_id = 0
    dataset = 'Rest14'
    model_name = 'bert_spc'
    batch_size = 32
    learning_rate = 3e-5
    num_epoch = 20
    train_path = os.path.join('data/Rest14/', 'Restaurants_Train.xml.seg')
    aug_path = os.path.join('data/Rest14/', 'Augmentation.seg')
    test_path = os.path.join('data/Rest14/', 'Restaurants_Test_bias_Gold.xml.seg')
    for ratio in [0,1,0.9,0.8, 0.7, 0.5,0.6,0.4,0.3,0.2,0.1]:
        result_path = os.path.join('Result/Rest14', 'bert_spc-%s.txt' % (ratio))  # 'Tweets,Lap14,Rest14-16',
        cmd = 'python train_k_fold.py ' + ' ' + \
              ' --device cuda:' + str(cuda_id) + ' ' + \
              ' --dataset ' + str(dataset) + ' ' + \
              ' --mix_ratio ' + str(ratio) + ' ' + \
              ' --num_epoch ' + str(num_epoch) + ' ' + \
              ' --batch_size ' + str(batch_size) + ' ' + \
              ' --learning_rate ' + str(learning_rate) + ' ' + \
              ' --model_name ' + str(model_name) + ' ' + \
              ' --train_file ' + str(train_path) + ' ' + \
              ' --aug_file ' + str(aug_path) + ' ' + \
              ' --test_file ' + str(test_path) + ' ' + \
              ' --result_file ' + str(result_path) + ' '
        run(cmd)
        sys.stdout.flush()
def per_data8():
    cuda_id = 1
    dataset = 'Rest15'
    model_name = 'bert_spc'
    batch_size = 32
    learning_rate = 3e-5
    num_epoch = 20
    train_path = os.path.join('data/Rest15/', 'restaurant_train.raw')
    aug_path = os.path.join('data/Rest15/', 'Augmentation.seg')
    test_path = os.path.join('data/Rest15/', 'restaurant_test_bias.raw')
    for ratio in [0.6, 0.5, 0.4, 0.3, 0.2, 0.1]:
        result_path = os.path.join('Result/Rest15', 'bert_spc-%s.txt' % (ratio))  # 'Tweets,Lap14,Rest14-16',
        cmd = 'python train_k_fold.py ' + ' ' + \
              ' --device cuda:' + str(cuda_id) + ' ' + \
              ' --dataset ' + str(dataset) + ' ' + \
              ' --mix_ratio ' + str(ratio) + ' ' + \
              ' --num_epoch ' + str(num_epoch) + ' ' + \
              ' --batch_size ' + str(batch_size) + ' ' + \
              ' --learning_rate ' + str(learning_rate) + ' ' + \
              ' --model_name ' + str(model_name) + ' ' + \
              ' --train_file ' + str(train_path) + ' ' + \
              ' --aug_file ' + str(aug_path) + ' ' + \
              ' --test_file ' + str(test_path) + ' ' + \
              ' --result_file ' + str(result_path) + ' '
        run(cmd)
        sys.stdout.flush()
def per_data9():
    cuda_id = 0
    dataset = 'Lap14'
    model_name = 'aen'
    batch_size = 32
    learning_rate = 1e-3
    num_epoch = 20
    train_path = os.path.join('data/Lap14/', 'Laptops_Train.xml.seg')
    aug_path = os.path.join('data/Lap14/', 'Augmentation.seg')
    test_path = os.path.join('data/Lap14/', 'Laptops_Test_bias.xml.seg')
    for ratio in [1,0,0.9,0.8,0.7,0.6,0.5,0.4,0.3,0.2,0.1]:
            result_path = os.path.join('Result/Lap14', 'nobert_aen-%s.txt' %(ratio) )  # 'Tweets,Lap14,Rest14-16',
            cmd = 'python train_k_fold.py ' + ' ' + \
                  ' --device cuda:' + str(cuda_id) + ' ' + \
                  ' --dataset ' + str(dataset) +' ' + \
                  ' --mix_ratio ' + str(ratio) + ' ' + \
                  ' --num_epoch ' + str(num_epoch) + ' ' + \
                  ' --batch_size ' + str(batch_size) + ' ' + \
                  ' --learning_rate ' + str(learning_rate) + ' ' + \
                  ' --model_name ' + str(model_name) + ' ' + \
                  ' --train_file ' + str(train_path) + ' ' + \
                  ' --aug_file ' + str(aug_path) + ' ' + \
                  ' --test_file ' + str(test_path) + ' ' + \
                  ' --result_file ' + str(result_path) + ' '
            run(cmd)
            sys.stdout.flush()
def per_data10():
    cuda_id = 1
    dataset = 'Res16'
    model_name = 'aen'
    batch_size = 32
    learning_rate = 1e-3
    num_epoch = 20
    train_path = os.path.join('data/Res16/', 'restaurant_train.raw')
    aug_path = os.path.join('data/Res16/', 'Augmentation.seg')
    test_path = os.path.join('data/Res16/', 'restaurant_test_bias.raw')
    for ratio in [1,0,0.9,0.8,0.7,0.6,0.5,0.4,0.3,0.2,0.1]:
            result_path = os.path.join('Result/Rest16', 'nobert_aen-%s.txt' %(ratio) )  # 'Tweets,Lap14,Rest14-16',
            cmd = 'python train_k_fold.py ' + ' ' + \
                  ' --device cuda:' + str(cuda_id) + ' ' + \
                  ' --dataset ' + str(dataset) +' ' + \
                  ' --mix_ratio ' + str(ratio) + ' ' + \
                  ' --num_epoch ' + str(num_epoch) + ' ' + \
                  ' --batch_size ' + str(batch_size) + ' ' + \
                  ' --learning_rate ' + str(learning_rate) + ' ' + \
                  ' --model_name ' + str(model_name) + ' ' + \
                  ' --train_file ' + str(train_path) + ' ' + \
                  ' --aug_file ' + str(aug_path) + ' ' + \
                  ' --test_file ' + str(test_path) + ' ' + \
                  ' --result_file ' + str(result_path) + ' '
            run(cmd)
            sys.stdout.flush()

def per_data11():
    cuda_id = 0
    dataset = 'Rest14'
    model_name = 'aen'
    batch_size = 32
    learning_rate = 1e-3
    num_epoch = 20
    train_path = os.path.join('data/Rest14/', 'Restaurants_Train.xml.seg')
    aug_path = os.path.join('data/Rest14/', 'Augmentation.seg')
    test_path = os.path.join('data/Rest14/', 'Restaurants_Test_bias_Gold.xml.seg')
    for ratio in [1, 0, 0.9, 0.1, 0.7, 0.6, 0.5, 0.4, 0.3, 0.2, 0.8]:
        result_path = os.path.join('Result/Rest14', 'n0bert_aen-%s.txt' % (ratio))  # 'Tweets,Lap14,Rest14-16',
        cmd = 'python train_k_fold.py ' + ' ' + \
              ' --device cuda:' + str(cuda_id) + ' ' + \
              ' --dataset ' + str(dataset) + ' ' + \
              ' --mix_ratio ' + str(ratio) + ' ' + \
              ' --num_epoch ' + str(num_epoch) + ' ' + \
              ' --batch_size ' + str(batch_size) + ' ' + \
              ' --learning_rate ' + str(learning_rate) + ' ' + \
              ' --model_name ' + str(model_name) + ' ' + \
              ' --train_file ' + str(train_path) + ' ' + \
              ' --aug_file ' + str(aug_path) + ' ' + \
              ' --test_file ' + str(test_path) + ' ' + \
              ' --result_file ' + str(result_path) + ' '
        run(cmd)
        sys.stdout.flush()

def per_data12():
    cuda_id = 1
    dataset = 'Rest15'
    model_name = 'aen'
    batch_size = 32
    learning_rate = 1e-3
    num_epoch = 20
    train_path = os.path.join('data/Rest15/', 'restaurant_train.raw')
    aug_path = os.path.join('data/Rest15/', 'Augmentation.seg')
    test_path = os.path.join('data/Rest15/', 'restaurant_test_bias.raw')
    for ratio in [1, 0, 0.9, 0.8, 0.7, 0.6, 0.5, 0.4, 0.3, 0.2, 0.1]:
        result_path = os.path.join('Result/Rest15', 'nobert_aen-%s.txt' % (ratio))  # 'Tweets,Lap14,Rest14-16',
        cmd = 'python train_k_fold.py ' + ' ' + \
              ' --device cuda:' + str(cuda_id) + ' ' + \
              ' --dataset ' + str(dataset) + ' ' + \
              ' --mix_ratio ' + str(ratio) + ' ' + \
              ' --num_epoch ' + str(num_epoch) + ' ' + \
              ' --batch_size ' + str(batch_size) + ' ' + \
              ' --learning_rate ' + str(learning_rate) + ' ' + \
              ' --model_name ' + str(model_name) + ' ' + \
              ' --train_file ' + str(train_path) + ' ' + \
              ' --aug_file ' + str(aug_path) + ' ' + \
              ' --test_file ' + str(test_path) + ' ' + \
              ' --result_file ' + str(result_path) + ' '
        run(cmd)
        sys.stdout.flush()
def per_data13():
    cuda_id = 0
    dataset = 'Lap14'
    model_name = 'tnet_lf'
    batch_size = 32
    learning_rate = 1e-3
    num_epoch = 20
    train_path = os.path.join('data/Lap14/', 'Laptops_Train.xml.seg')
    aug_path = os.path.join('data/Lap14/', 'Augmentation.seg')
    test_path = os.path.join('data/Lap14/', 'Laptops_Test_bias.xml.seg')
    for ratio in [0.4,0.3,0.2,0.1]:
            result_path = os.path.join('Result/Lap14', 'nobert_tnet_lf-%s.txt' %(ratio) )  # 'Tweets,Lap14,Rest14-16',
            cmd = 'python train_k_fold.py ' + ' ' + \
                  ' --device cuda:' + str(cuda_id) + ' ' + \
                  ' --dataset ' + str(dataset) +' ' + \
                  ' --mix_ratio ' + str(ratio) + ' ' + \
                  ' --num_epoch ' + str(num_epoch) + ' ' + \
                  ' --batch_size ' + str(batch_size) + ' ' + \
                  ' --learning_rate ' + str(learning_rate) + ' ' + \
                  ' --model_name ' + str(model_name) + ' ' + \
                  ' --train_file ' + str(train_path) + ' ' + \
                  ' --aug_file ' + str(aug_path) + ' ' + \
                  ' --test_file ' + str(test_path) + ' ' + \
                  ' --result_file ' + str(result_path) + ' '
            run(cmd)
            sys.stdout.flush()
def per_data14():
    cuda_id = 1
    dataset = 'Res16'
    model_name = 'tnet_lf'
    batch_size = 32
    learning_rate = 1e-3
    num_epoch = 20
    train_path = os.path.join('data/Res16/', 'restaurant_train.raw')
    aug_path = os.path.join('data/Res16/', 'Augmentation.seg')
    test_path = os.path.join('data/Res16/', 'restaurant_test_bias.raw')
    for ratio in [1,0,0.9,0.8,0.7,0.6,0.5,0.4,0.3,0.2,0.1]:
            result_path = os.path.join('Result/Rest16', 'nobert_tnet_lf-%s.txt' %(ratio) )  # 'Tweets,Lap14,Rest14-16',
            cmd = 'python train_k_fold.py ' + ' ' + \
                  ' --device cuda:' + str(cuda_id) + ' ' + \
                  ' --dataset ' + str(dataset) +' ' + \
                  ' --mix_ratio ' + str(ratio) + ' ' + \
                  ' --num_epoch ' + str(num_epoch) + ' ' + \
                  ' --batch_size ' + str(batch_size) + ' ' + \
                  ' --learning_rate ' + str(learning_rate) + ' ' + \
                  ' --model_name ' + str(model_name) + ' ' + \
                  ' --train_file ' + str(train_path) + ' ' + \
                  ' --aug_file ' + str(aug_path) + ' ' + \
                  ' --test_file ' + str(test_path) + ' ' + \
                  ' --result_file ' + str(result_path) + ' '
            run(cmd)
            sys.stdout.flush()

def per_data15():
    cuda_id = 0
    dataset = 'Rest14'
    model_name = 'tnet_lf'
    batch_size = 32
    learning_rate = 1e-3
    num_epoch = 20
    train_path = os.path.join('data/Rest14/', 'Restaurants_Train.xml.seg')
    aug_path = os.path.join('data/Rest14/', 'Augmentation.seg')
    test_path = os.path.join('data/Rest14/', 'Restaurants_Test_bias_Gold.xml.seg')
    for ratio in [1, 0, 0.9, 0.1, 0.7, 0.6, 0.5, 0.4, 0.3, 0.2, 0.8]:
        result_path = os.path.join('Result/Rest14', 'nobert_tnet_lf-%s.txt' % (ratio))  # 'Tweets,Lap14,Rest14-16',
        cmd = 'python train_k_fold.py ' + ' ' + \
              ' --device cuda:' + str(cuda_id) + ' ' + \
              ' --dataset ' + str(dataset) + ' ' + \
              ' --mix_ratio ' + str(ratio) + ' ' + \
              ' --num_epoch ' + str(num_epoch) + ' ' + \
              ' --batch_size ' + str(batch_size) + ' ' + \
              ' --learning_rate ' + str(learning_rate) + ' ' + \
              ' --model_name ' + str(model_name) + ' ' + \
              ' --train_file ' + str(train_path) + ' ' + \
              ' --aug_file ' + str(aug_path) + ' ' + \
              ' --test_file ' + str(test_path) + ' ' + \
              ' --result_file ' + str(result_path) + ' '
        run(cmd)
        sys.stdout.flush()

def per_data16():
    cuda_id = 1
    dataset = 'Rest15'
    model_name = 'tnet_lf'
    batch_size = 32
    learning_rate = 1e-3
    num_epoch = 20
    train_path = os.path.join('data/Rest15/', 'restaurant_train.raw')
    aug_path = os.path.join('data/Rest15/', 'Augmentation.seg')
    test_path = os.path.join('data/Rest15/', 'restaurant_test_bias.raw')
    for ratio in [1, 0, 0.9, 0.8, 0.7, 0.6, 0.5, 0.4, 0.3, 0.2, 0.1]:
        result_path = os.path.join('Result/Rest15', 'nobert_tnet_lf-%s.txt' % (ratio))  # 'Tweets,Lap14,Rest14-16',
        cmd = 'python train_k_fold.py ' + ' ' + \
              ' --device cuda:' + str(cuda_id) + ' ' + \
              ' --dataset ' + str(dataset) + ' ' + \
              ' --mix_ratio ' + str(ratio) + ' ' + \
              ' --num_epoch ' + str(num_epoch) + ' ' + \
              ' --batch_size ' + str(batch_size) + ' ' + \
              ' --learning_rate ' + str(learning_rate) + ' ' + \
              ' --model_name ' + str(model_name) + ' ' + \
              ' --train_file ' + str(train_path) + ' ' + \
              ' --aug_file ' + str(aug_path) + ' ' + \
              ' --test_file ' + str(test_path) + ' ' + \
              ' --result_file ' + str(result_path) + ' '
        run(cmd)
        sys.stdout.flush()
def del_file(path):
    for i in os.listdir(path):
        path_file = os.path.join(path, i)  # 取文件绝对路径
        if os.path.isfile(path_file):
            os.remove(path_file)
        else:
            del_file(path_file)

def  multi_works1(func1,func2):
    proc_record = []
    p0 = Process(target=func1, args=())
    p0.start()
    proc_record.append(p0)
    p1 = Process(target=func2, args=())
    p1.start()
    proc_record.append(p1)
    for p in proc_record:
          p.join()

    print("start deleting model file....")
    if os.path.exists('state_dict'):
        # os.remove('state_dict')
        del_file('state_dict')
    print("end deleting model file....")

def  multi_works2(func1,func2):
    proc_record = []
    p0 = Process(target=func1, args=())
    p0.start()
    proc_record.append(p0)
    p1 = Process(target=func2, args=())
    p1.start()
    proc_record.append(p1)
    for p in proc_record:
          p.join()

    print("start deleting model file....")
    if os.path.exists('state_dict'):
        # os.remove('state_dict')
        del_file('state_dict')
    print("end deleting model file....")

if __name__ == '__main__':
   # per_data13()
    multi_works1(per_data1,per_data2)
    multi_works2(per_data3,per_data4)



